// AdminDashboard.jsx
import React, { useEffect, useState } from 'react';
import { useHistory } from 'react-router-dom';
import axios from 'axios';
import EventList from '../components/EventList';
import './AdminDashboard.css';

const AdminDashboard = () => {
  const [events, setEvents] = useState([]);
  const [message, setMessage] = useState('');
  const history = useHistory();

  const fetchEvents = async () => {
    const token = localStorage.getItem('token');
    if (!token) {
      setMessage('You must be logged in to view events.');
      return;
    }
    try {
      const res = await axios.get(`http://localhost:5000/api/events`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      setEvents(res.data);
    } catch (err) {
      console.error('Failed to fetch events:', err);
      setMessage('Failed to fetch events');
    }
  };

  useEffect(() => {
    fetchEvents();
  }, []);

  return (
    <div className="admin-dashboard">
      <nav className="sidebar">
        <h2>Dashboard</h2>
        <ul>
          <li onClick={() => history.push('/admin-dashboard')}>Upcoming Events</li>
          <li onClick={() => history.push('/edit-events')}>Edit Events</li>
          <li onClick={() => history.push('/create-event')}>Create Event</li>
          <li onClick={() => alert('Notifications coming soon!')}>Notifications</li>
          <li onClick={() => alert('Profile coming soon!')}>Profile</li>
        </ul>
      </nav>

      <main className="main-content">
        {message && (
          <p className={message.includes('Failed') ? 'message-error' : 'message-success'}>
            {message}
          </p>
        )}
        <EventList events={events} showActions={false} />
      </main>
    </div>
  );
};

export default AdminDashboard;
